def impar(numero):

    if numero % 2 != 0:
        return True
    else:
        return False


def main():
    numero = 3
    print(impar(numero))


if __name__ == "__main__":
    main()


